package com.example.umprojetoae;

import com.google.firebase.messaging.FirebaseMessagingService;

public class CDCMessasingService extends FirebaseMessagingService {
}
